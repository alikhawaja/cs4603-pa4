"""MCP tool server package."""
